"""djangoProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app01 import views

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('index/', views.index),
    path('user/list', views.user_list),
    path('user/add', views.user_add),
    path('tpl', views.tpl),
    path('news/', views.news),
    path('something/', views.something),
    path('login/', views.login),
    # 用户
    path('denglu/', views.denglu),
    path('zhuce/', views.zhuce),
    # path('yonghuzhuye/', views.yonghuzhuye),
    # path('shebeitianjia/', views.tianjia),
    # 管理员
    path('guanlidenglu/', views.guanlidenglu),
    path('guanli1/<int:nid>delete/', views.guanli1_delete),
    path('guanli1/<int:nid>edit/', views.guanli1_edit),
    path('guanlizhuye/', views.guanlizhuye),
    path('houtaizhuye/', views.houtaizhuye),
    path('guanligoumai/', views.guanligoumai),
    path('guanli/<int:nid>delete/', views.goumai_delete),
    # 主页面
    path('zhuyemian/', views.zhuyemian),
    path('zhuyemian2/', views.zhuyemian2),
    path('goumai/', views.goumai),
    path('yonghugoumai/', views.yonghugoumai),
    # 设备
    path('shebei/', views.shebei),
    path('shebei_add/', views.shebei_add),
    path('yonghugoumai/', views.yonghugoumai),
    path('shebei/<int:nid>delete/', views.shebei_delete),
    path('shebei/<int:nid>edit/', views.shebei_edit),

    path('charlist/charlist/', views.char_list),
    # 评价
    path('yonghupingjia/', views.yonghupingjia),
    path('yonghupingjia_add/', views.yonghupingjia_add),
    path('yonghupingjia/<int:nid>delete/', views.yonghupingjia_delete),
    path('yonghupingjia/<int:nid>edit/', views.yonghupingjia_edit),
    path('pingjiachenggong/', views.pingjiachenggong),




]
