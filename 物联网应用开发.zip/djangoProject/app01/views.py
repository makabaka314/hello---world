import queue
import threading

from django.shortcuts import render, HttpResponse, redirect
from app01 import models

# Create your views here.
def index(request):
    return HttpResponse('欢迎使用')


def user_list(request):
    return render(request,"user_list.html")

def user_add(request):
    return render(request,"user_add.html")

def tpl(request):
    name='李广璐'
    roles=['管理员','ceo','保安']
    user_info={'name':'lgl', 'salary':100000,'role':'cto'}
    data_list=[
        {'name': 'lgl', 'salary': 10000000, 'role': 'cto'},
        {'name': '张三', 'salary': 10000, 'role': '保安'},
        {'name': '李四', 'salary': 100000, 'role': 'ceo'}
    ]
    return render(request,"tpl.html",{'n1':name,'n2':roles,'n3':user_info,'n4':data_list})

def news(req):
    import requests
    res = requests.get('https://m.jf.10010.com/jf-log/action?domain=img.client.10010.com&href=https%3A%2F%2Fimg.client.10010.com%2Fjifenshangchengpc%2Findex.html%23%2F&operation=click&localUrl=https%3A%2F%2Fimg.client.10010.com%2Fjifenshangchengpc%2Findex.html%23%2F&nodename=A&path=A0LI1jingcaiBody1jingcaiContainer0index_div2index0DIV0app&stc=&citycode=&jfuser=%7C%7C&t=1651483969080&uuid=c52a4a16-1fb6-4541-8c44-f204490930a9')
    data_list = res.json()
    print(data_list)
    return render(req,'news.html')

def something(request):
    print(request.method)


    print(request.GET)

    print(request.POST)
    #return render(request,'something.html',{'title':'来了'})
    return redirect('http://www.baidu.com')
def login(request):
    if request.method == 'GET':
        return render(request,'login.html')
    else:
        print(request.POST)
    username = request.POST.get('user')
    password = request.POST.get('pwd')
    if username == 'root' and password == '123':
        return HttpResponse('登陆成功')
    else:
        return render(request,'login.html',{'error_msg':'用户名或密码错误'})
from app01 import models
from app01.models import Denglu


# 登录
def denglu(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        password = request.POST.get('password')

        if Denglu.objects.filter(name=name):
            Denglu.objects.filter(name=name)
            if Denglu.objects.filter(name = name)[0].password == password:
                return render(request,'zhuyemian2.html')
            else:
                return HttpResponse('密码错误，登录失败')
    return render(request,'denglu.html')

# 注册
def zhuce(request):
    if request.method == 'GET':
        return render(request,'zhuce.html')

    name = request.POST.get('name')
    password = request.POST.get('password')
    models.Denglu.objects.create(name=name,password=password)
    return redirect('/denglu/')

# # 用户主页
# def yonghuzhuye(request):
#     queryset = models.Shebei.objects.all()
#     return render(request,'shebei.html',{'queryset':queryset})
#
# # 设备添加
# def tianjia(request):
#     if request.method == 'GET':
#         return render(request,'shebeitianjia.html')
#
#     name = request.POST.get('name')
#     count = request.POST.get('count')
#     price = request.POST.get('price')
#     models.Shebei.objects.create(name=name,count=count,price=price)
#     return redirect('/yonghuzhuye/')




# 管理登录
def guanlidenglu(request):
        # 如果是get请求
        if request.method == 'GET':
            return render(request, 'guanlidenglu.html')
    # 如果是POST请求，则获取用户提交的数据
        else:
            username = request.POST.get('user')
            password = request.POST.get('pwd')
            # 对用户提交的数据进行比对,正确的话跳转主页
            if username == '李广璐' and password == '123456':
                return render(request, 'houtaizhuye.html')
            # 错误的话提示错误
            else:
                return render(request, 'guanlidenglu.html', {"error_msg": "管理员用户名或密码错误"})
# 管理主页
def guanlizhuye(request):
    queryset = models.Denglu.objects.all()
    return render(request,'guanlizhuye.html',{'queryset':queryset})
def guanli1_delete(request,nid):
    models.Denglu.objects.filter(id=nid).delete()
    return redirect('/guanlizhuye/')
def guanli1_edit(request,nid):
    if request.method == 'GET':
        row_object = models.Denglu.objects.filter(id=nid).first()
        return render(request, 'guanli_edit.html', {'row_object': row_object})
    # 提交修改值
    name = request.POST.get('name')
    password = request.POST.get('password')
    models.Denglu.objects.filter(id=nid).update(name=name, password=password)
    return redirect('/guanlizhuye/')


def houtaizhuye(request):
    return render(request,'houtaizhuye.html')
def guanligoumai(request):
    # 获取所有用户列表
    queryset = models.Baojia.objects.all()
    return render(request, 'guanligoumai.html', {'queryset': queryset})
# 删除操作
def goumai_delete(request,nid):
    models.Baojia.objects.filter(id=nid).delete()
    return redirect('/guanligoumai/')

# 主页面
def zhuyemian(request):
    return render(request,'zhuyemian.html')
def zhuyemian2(request):
    return render(request,'zhuyemian2.html')

# 购买
def goumai(request):
    # 获取所有用户列表
    queryset = models.Baojia.objects.all()
    return render(request,'goumai.html',{'queryset':queryset})

# 添加
from django import forms
class UserModelForm(forms.ModelForm):
    class Meta:
        model = models.Baojia
        fields = ['name','leixing','count']

# 保存样式
def __init__(self,*args,**kwargs):
    super().__init__(*args,**kwargs)
# 添加样式
    for name,field in self.items():
        field.widget.attrs = {'class':'form-control','placeholder':field.label}
# 用户购票
def yonghugoumai(request):
    if request.method == 'GET':
        form = UserModelForm()
        return render(request, 'yonghugoumai.html', {'form': form})
# 提交
    form = UserModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/goumai/')


def shebei(request):
    # 获取所有用户列表
    queryset = models.Shebei.objects.all()
    return render(request, 'shebei.html', {'queryset': queryset})
# 设备增加
# from django import forms
# class sheModelForm(forms.ModelForm):
#         class Meta:
#             model = models.Shebei
#             fields = ['name', 'count', 'state']
# def shebei_add(request):
#         if request.method == 'GET':
#             form = sheModelForm()
#             return render(request, 'shebei_add.html', {'form': form})
#         # 提交
#         form = sheModelForm(data=request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('/shebei/')

def shebei_add(request):
    if request.method == 'GET':
        return render(request, 'shebei_add.html')

    # 获取提交的数据
    name = request.POST.get('name')
    count = request.POST.get('count')
    # 保存到数据库
    models.Shebei.objects.create(name=name,count=count,price='离线')

    # 重定向回部门列表
    return redirect('/shebei/')
def shebei_delete(request,nid):
    models.Shebei.objects.filter(id=nid).delete()
    return redirect('/shebei/')
def shebei_edit(request,nid):
    # 根据id获取他的原数据
    if request.method == 'GET':
        row_object = models.Shebei.objects.filter(id=nid).first()
        return render(request, 'shebei_edit.html', {'row_object': row_object})
# 提交修改值
    name = request.POST.get('name')
    count = request.POST.get('count')
    models.Shebei.objects.filter(id=nid).update(name=name,count=count)
    return redirect('/shebei/')

# 实时数据统计
# 折线图
import random
import time
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
@csrf_exempt
def char_list(request):
    if request.method == 'POST':
        now_time = time.strftime("%H:%M:%S")
        num = random.randint(20, 36)
        return JsonResponse({"datas": {"local_time": now_time, "num": num}})
    return render(request, 'char_list.html')
def yonghupingjia(request):
    queryset = models.Pingjia.objects.all()
    return render(request,'yonghupingjia.html',{'queryset': queryset})

from django import forms
class pingModelForm(forms.ModelForm):
        class Meta:
            model = models.Pingjia
            fields = ['name', 'shebeileixing', 'pingjia']

    # 保存样式
def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
        # 添加样式
    for name, field in self.items():
        field.widget.attrs = {'class': 'form-control', 'placeholder': field.label}

    # 用户购票
def yonghupingjia_add(request):
        if request.method == 'GET':
            form = pingModelForm()
            return render(request, 'yonghupingjia_add.html', {'form': form})
        # 提交
        form = pingModelForm(data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('/pingjiachenggong/')
def pingjiachenggong(request):
    return render(request,'pingjiachenggong.html')
    # if request.method == 'GET':
    #     return render(request, 'yonghupingjia_add.html')
    #
    # # 获取提交的数据
    # name = request.POST.get('name')
    # pingjia = request.POST.get('pingjia')
    # # 保存到数据库
    # models.Pingjia.objects.create(name=name,pingjia=pingjia)
    #
    # # 重定向回部门列表
    # return redirect('/yonghupingjia/')
def yonghupingjia_delete(request,nid):
    models.Pingjia.objects.filter(id=nid).delete()
    return redirect('/yonghupingjia/')
def yonghupingjia_edit(request,nid):
    # 根据id获取他的原数据
    if request.method == 'GET':
        row_object = models.Pingjia.objects.filter(id=nid).first()
        return render(request, 'yonghupingjia_edit.html', {'row_object': row_object})
# 提交修改值
    name = request.POST.get('name')
    pingjia = request.POST.get('pingjia')
    models.Pingjia.objects.filter(id=nid).update(name=name,pingjia=pingjia)
    return redirect('/yonghupingjia/')