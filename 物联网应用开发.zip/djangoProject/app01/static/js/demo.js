window.onload = function () {
    var myChart = echarts.init(document.getElementById('main'));
    // 指定图表的配置项和数据
        var option = {
            color:["red"],
            backgroundColor:['#f1f1f1'],
            title: {
                text: '设备数据'
            },
            tooltip: {},
            legend: {
                data:['销量']
            },
            xAxis: {
                name: "时间点",
                data: [],
            },
            yAxis: {
                name: "当前访问人数",
            },
            series: [{
                type: 'line',
                data: [],
            }]
        };

    var now_timeList = []
    var num_List = []
    var start_btn = document.getElementById('start')
    var stop_btn = document.getElementById('stop')
    function getList() {
        $.ajax({
            url: '/charlist/charlist/',
            type: 'POST',
            dataType:"json",
            success: function (data) {
                num_List.push(data.datas.num);
                now_timeList.push(data.datas.local_time);
                option.xAxis.data = now_timeList;
                option.series[0].data = num_List;
                myChart.setOption(option);
            }
        })
    }
    //初始化图表
    myChart.setOption(option);
    start_btn.onclick = function(){
        time = setInterval(getList, 1000);
    }
    stop_btn.onclick = function() {
        clearInterval(time)
    }
}
