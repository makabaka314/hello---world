from django.db import models

# Create your models here.
# class UserInfo(models.Model):
#     name = models.CharField(max_length=32)
#     password = models.CharField(max_length=64)
#     age = models.IntegerField()

# class Department(models.Model):
#     title = models.CharField(max_length=32)
class Denglu(models.Model):
    name = models.CharField(max_length=32)
    password = models.CharField(max_length=64)

class Shebei(models.Model):
    name = models.CharField(max_length=32)
    count = models.CharField(max_length=64)
    price = models.CharField(max_length=32)
    # 转换为汉字
    def __str__(self):
        return self.name

# 用户购买表
class Baojia(models.Model):
    name = models.CharField(verbose_name='用户名称',max_length=32)
    leixing = models.ForeignKey(verbose_name='购买类型选择', to='Shebei', to_field='id', on_delete=models.CASCADE)
    count = models.CharField(verbose_name='购买数量',max_length=32)
# 设备表：
class MAClist(models.Model):
    MAC = models.CharField(max_length=32)
    Name = models.CharField(max_length=32)
    state = models.CharField(max_length=32)
# 用户评价
class Pingjia(models.Model):
    name = models.CharField(verbose_name='用户姓名',max_length=32)
    shebeileixing = models.ForeignKey(verbose_name='设备类型', to='Shebei', to_field='id', on_delete=models.CASCADE)
    pingjia = models.CharField(verbose_name='请评价：',max_length=32)
