import requests
import json
import base64

def sc(tokenNum,a):
    url = 'http://ai.heclouds.com:9090/v1/aiApi/picture/NUMBER_PLATE_RECOGNITION'
    headers = {
        'Content-Type': 'application/json',
        'Login-Token': tokenNum
    }
    file = open(a, 'rb')
    str = base64.b64encode(file.read()).decode()
    file.close()
    data = {
        'type': 'GPU',  # 可选参数，填入“GPU”则代表使用GPU版本api，否则使用CPU版本api
        'picture': [str]
    }
    req = requests.post(url, data=json.dumps(data), headers=headers)
    req1=json.loads(req.text)
    return req1["data"]